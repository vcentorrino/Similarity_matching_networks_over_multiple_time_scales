# Code to run the simulation in Section 6, paragraph "Comparison with the algorithm in [Pehlevan et al., 2017b]"

import numpy as np
import random
import matplotlib.pyplot as plt
from matplotlib import rc
import seaborn as sns
from scipy.integrate import solve_ivp
from scipy.optimize import minimize, least_squares

# PLOT SETTINGS
sns.set(style="whitegrid")
font = {'size': 16}
plt.rc('font', **font)
rc('text', usetex=True)
rc('font', family='serif')

# ============================================================================
#                           Functions
# ============================================================================
def svd_eigenvalues(matrix, full_decomposition):
    """
    Computes the singular values of a matrix using Singular Value Decomposition (SVD).

    Parameters:
        matrix (ndarray): The input matrix to decompose.
        full_decomposition (bool): If True, returns (U, S, VT); otherwise, returns only S.

    Output:
        ndarray or tuple: Singular values if full_decomposition is False;
                          (U, S, VT) otherwise, where:
                           -  U = Unitary matrix with left singular vectors as columns.
                           -  S = 1-D array of singular values.
                           - VT = Unitary matrix with right singular vectors as rows.
    """
    U, S, VT = np.linalg.svd(matrix)
    return (U, S, VT) if full_decomposition else S

def cost_function_SM(X, Y):
    """
    Computes the similarity matching cost function: (1/T^2) * ||X^T X - Y^T Y||_F^2.

    Parameters:
        X (ndarray): Input data matrix of shape (n, T).
        Y (ndarray): Output data matrix of shape (m, T).

    Output:
        float: The computed cost value.
    """
    T = X.shape[1]
    frobenius_norm = np.linalg.norm(X.T @ X - Y.T @ Y, 'fro')
    return (frobenius_norm**2) / T**2

def compute_Y_opt(X, m):
    """
    Computes the optimal Y^star from [Liu et al., 2015].

    Parameters:
        X (ndarray): Input data matrix of shape (n, T).
        m (int): Dimensionality of the output representation (m <= n).

    Output:
        ndarray: Optimal output data matrix of shape (m, T).
    """
    eigenvalues, eigenvectors = np.linalg.eigh(X.T @ X)
    # Sort eigenvalues and corresponding eigenvectors in descending order
    idx = np.argsort(eigenvalues)[::-1]
    top_eigenvectors = eigenvectors[:, idx[:m]]
    top_eigenvalues = eigenvalues[idx[:m]]
    L_m = np.diag(top_eigenvalues)
    return np.sqrt(L_m) @ top_eigenvectors.T

def similarity_matching(W_0, M_0, X, m, eta, tau, max_iter=10000, tol=1e-6):#800
    """
    Solves the similarity matching problem using the offline algorithm in [Pehlevan et al., 2017]

    Parameters:
        X (ndarray): Input data matrix of shape (n, T).
        m (int): Dimensionality of the output representation (m <= n).
        k_w (float): Scaling factor for the initial weight matrix.
        eta (float): Step size for updates.
        tau (float): Scaling factor for the update step of M.
        max_iter (int): Maximum number of iterations.
        tol (float): Convergence tolerance for stopping criterion.

    Output:
        tuple: (Y, M, W) where:
            Y (ndarray): Output data matrix of shape (m, T).
            M (ndarray): Positive definite matrix of shape (m, m).
            W (ndarray): Weight matrix of shape (m, n).
    """
    n, k = X.shape
    W = W_0
    M = M_0

    for i in range(max_iter):
        # Minimize with respect to Y
        Y = np.linalg.solve(M, W @ X)

        # Compute updates for W and M
        W_new = W + 2 * eta * ((Y @ X.T / k) - W)
        M_new = M + (eta / tau) * ((Y @ Y.T / k) - M)

        if (np.linalg.norm(W_new - W, ord='fro') < tol and 
            np.linalg.norm(M_new - M, ord='fro') < tol):
            print(f"Converged in {i+1} iterations.")
            break

        W, M = W_new, M_new
    return Y, M, W

def simulate_dynamics(W_0, M_0, Y_0, X, eps1, eps2, T, t_span, dt):
    """
    Simulates the dynamics with added noise in Y and M.

    Parameters:
        W_0 (ndarray): Initial condition for W.
        M_0 (ndarray): Initial condition for M.
        Y_0 (ndarray): Initial condition for Y.
        X (ndarray): Input data matrix of shape (n, T).
        eps1 (float): Small parameter for fastest time scale.
        eps2 (float): Small parameter for intermediate time scale.
        T (int): Number of data points (scaling).
        t_span (tuple): Time range for simulation (start, end).
        dt (float): Time step size for simulation.
        noise_scale (float): Scale of Gaussian noise added to dynamics (default 0.0).

    Outputs:
        tuple: (t, Y, M, W) where:
            t (ndarray): Time points;
            Y (ndarray): Solution array for Y;
            M (ndarray): Solution array for M;
            W (ndarray): Solution array for W.
    """
    n, T = X.shape
    m = W_0.shape[0]

    def system(t, z):
        W = z[:m * n].reshape(m, n)
        M = z[m * n:m * n + m * m].reshape(m, m)
        Y = z[m * n + m * m:].reshape(m, T)

        # Dynamics
        dW_dt = -4 * W + (4 / T) * Y @ X.T
        dM_dt = (-2 / eps2) * M + (2 / (T * eps2)) * Y @ Y.T
        dY_dt = (-4 / (T * eps1 * eps2)) * (M @ Y - W @ X)
        return np.concatenate([dW_dt.ravel(), dM_dt.ravel(), dY_dt.ravel()])

    # Initial conditions
    z0 = np.concatenate([W_0.ravel(), M_0.ravel(), Y_0.ravel()])
    t_eval = np.arange(t_span[0], t_span[1], dt)

    # Solve the system
    sol = solve_ivp(system, t_span, z0, t_eval=t_eval, method='RK45')

    # Extract results
    t = sol.t
    W = sol.y[:m * n].reshape(m, n, -1)
    M = sol.y[m * n:m * n + m * m].reshape(m, m, -1)
    Y = sol.y[m * n + m * m:].reshape(m, T, -1)
    return t, Y, M, W

# ============================================================================
#                               Simulation
# ============================================================================
T = True
F = False
run_params = F
run_liu = F
run = F

#########################
simulation_params_path = 'simulation_parameters.npz'
if run_params:
    # Parameters
    n = 10                   # Dimensionality of the dataset
    m = 3                    # Reduced dimensionality
    k = 2000                 # Number of data points

    # Generate the data matrix X from its SVD -- Similar to 2017 Pehlevan, C., Sengupta, A. M., and Chklovskii, D. B.
    left_singular_vectors = np.linalg.qr(np.random.randn(n, n))[0]
    right_singular_vectors = np.linalg.qr(np.random.randn(k, n))[0]
    top_singular_values = [np.sqrt(3 * k), np.sqrt(2 * k), np.sqrt(k)]
    additional_singular_values = np.random.uniform(0, 0.1 * np.sqrt(k), n - 3)
    all_singular_values = np.concatenate((top_singular_values, additional_singular_values))
    X = left_singular_vectors @ np.diag(all_singular_values) @ right_singular_vectors.T
    print("all_singular_values = ", all_singular_values)

    C_X = X @ X.T / k
    np.savez_compressed(simulation_params_path, n=n, m=m, k=k, X=X, C_X=C_X)
else:
    params = np.load(simulation_params_path)
    n, m, k, X, C_X = params['n'], params['m'], params['k'], params['X'], params['C_X']

#########################
simulation_opt_liu_path = 'simulation_opt_liu.npz'
if run_liu:
    Y_opt_liu = compute_Y_opt(X, m)
    result_opt_liu = cost_function_SM(X, Y_opt_liu)
    np.savez_compressed(simulation_opt_liu_path, Y_opt_liu=Y_opt_liu, result_opt_liu=result_opt_liu)
else:
    opt_liu = np.load(simulation_opt_liu_path)
    Y_opt_liu, result_opt_liu = opt_liu['Y_opt_liu'], opt_liu['result_opt_liu']

###########################################
number_of_steps = 500
simulation_same_ic_path = 'simulation_comparison.npz'
t_span = (0, 50)
dt = 0.01
eps1, eps2 = 0.01, 0.5
eta = 0.01
tau = 0.5

result_dyn = []
Y0_list = []
W0_list = []
M0_list = []
eigenvalues_Y_dyn_list = []
eigenvalues_W_dyn_list = []
result_PC = []
eigenvalues_Y_PC_list = []
eigenvalues_W_PC_list = []
if run:
    for step in range(number_of_steps):
        Y_0 = np.random.randn(m, k)
        print(f"Step = {step + 1}/{number_of_steps}")
        W_0 = - np.random.randn(m, n)
        M_0 = np.diag(np.abs(np.random.randn(m)))
        if step == 100:
            W_0 = np.zeros((m, n))
            W_0[0, 0] = np.random.randn()
            W_0[1, 1] = np.random.randn()
        if step == 200:
            W_0 = np.zeros((m, n))
            W_0[0, 0] = np.random.randn()
        if step == 300:
            W_0 = np.zeros((m, n))
        Y0_list.append(Y_0)
        M0_list.append(M_0)
        W0_list.append(W_0)
        # PC
        Y_PC, M_PC, W_PC = similarity_matching(W_0, M_0, X, m, eta, tau)
        result_PC.append(cost_function_SM(X, Y_PC))
        eigenvalues_Y_PC_list.append(svd_eigenvalues(Y_PC, False))
        eigenvalues_W_PC_list.append(svd_eigenvalues(W_PC, False))
        # Simulate dynamics
        t_dyn, Y_dyn, M_dyn, W_dyn = simulate_dynamics(W_0, M_0, Y_0, X, eps1, eps2, k, t_span, dt)
        result_dyn.append(cost_function_SM(X, Y_dyn[:, :, -1]))
        eigenvalues_Y_dyn_list.append(svd_eigenvalues(Y_dyn[:, :, -1], False))
        eigenvalues_W_dyn_list.append(svd_eigenvalues(W_dyn[:, :, -1], False))

    np.savez_compressed(simulation_same_ic_path,
                    Y0_list=Y0_list, M0_list=M0_list, W0_list=W0_list,
                    eigenvalues_Y_PC_list=eigenvalues_Y_PC_list,
                    eigenvalues_W_PC_list=eigenvalues_W_PC_list,
                    result_PC=result_PC,
                    eigenvalues_Y_dyn_list=eigenvalues_Y_dyn_list,
                    eigenvalues_W_dyn_list=eigenvalues_W_dyn_list,
                    result_dyn=result_dyn)
else:
    load_both = np.load(simulation_same_ic_path)
    Y0_list = load_both['Y0_list']
    M0_list = load_both['M0_list']
    W0_list = load_both['W0_list']
    eigenvalues_Y_PC_list = load_both['eigenvalues_Y_PC_list']
    eigenvalues_W_PC_list = load_both['eigenvalues_W_PC_list']
    result_PC = load_both['result_PC']
    eigenvalues_Y_dyn_list = load_both['eigenvalues_Y_dyn_list']
    eigenvalues_W_dyn_list = load_both['eigenvalues_W_dyn_list']
    result_dyn = load_both['result_dyn']
# ============================================================================
#                               PLOTS
# ============================================================================
if run:
    eigenvalues_Y_PC_list = np.array(eigenvalues_Y_PC_list)
    eigenvalues_W_PC_list = np.array(eigenvalues_W_PC_list)
    eigenvalues_Y_dyn_list = np.array(eigenvalues_Y_dyn_list)
    eigenvalues_W_dyn_list = np.array(eigenvalues_W_dyn_list)    
save_fig = T
#### First Plot: Cost Difference Comparison
number_of_steps_dyn = len(result_dyn)
result_diff_PC = np.array(result_PC) - np.array(result_opt_liu)
result_diff_dyn = np.array(result_dyn) - np.array(result_opt_liu)

#fig, ax = plt.subplots(1, 2, figsize=(15, 4.5))
fig, ax = plt.subplots(2, 1, figsize=(10, 6))
ax[0].plot(range(1, number_of_steps_dyn + 1), result_diff_dyn, label=r'$SM(Y_{dyn}) - SM(Y^{\star})$', color='royalblue', linewidth=1.5)
ax[0].set_xlim([1, number_of_steps])
ax[0].legend(fontsize=16)
ax[0].grid(True, linestyle='--', alpha=0.7)
ax[0].tick_params(axis='both', labelsize=16)
ax[0].set_xticks([1, 100, 200, 300, 400, 500])
ax[1].plot(range(1, number_of_steps_dyn + 1), result_diff_PC, label=r'$SM(Y_{P}) - SM(Y^{\star})$', color='darkgreen', linewidth=1.5)
ax[1].set_xlim([1, number_of_steps])
ax[1].legend(fontsize=16)
ax[1].grid(True, linestyle='--', alpha=0.7)
ax[1].tick_params(axis='both', labelsize=16)
ax[1].set_xticks([1, 100, 200, 300, 400, 500])
fig.text(0.53, 0.03, 'Simulation', ha='center', fontsize=20)
fig.text(0.03, 0.5, r'Cost Difference', va='center', rotation='vertical', fontsize=20)
plt.tight_layout(rect=[0.05, 0.05, 1, 0.95])
if save_fig:
    plt.savefig(f'cost_diff_dyn_pc_run_{k}_eps1_{eps1:.2f}_eps2_{eps2:.2f}_NC.eps', bbox_inches='tight')
    #plt.savefig(f'cost_diff_dyn_pc_run_{k}_eps1_{eps1:.2f}_eps2_{eps2:.2f}.eps', bbox_inches='tight')
plt.show()

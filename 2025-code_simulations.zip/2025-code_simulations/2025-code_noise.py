# Code to run the simulation in Section 6, paragraph "Robustness to noise"

import numpy as np
import random
import matplotlib.pyplot as plt
from matplotlib import rc
from scipy.integrate import solve_ivp
from scipy.optimize import minimize, least_squares
import seaborn as sns

# PLOT SETTINGS
sns.set(style="whitegrid")
font = {'size': 16}
plt.rc('font', **font)
rc('text', usetex=True)
rc('font', family='serif')

# ============================================================================
#                           Functions
# ============================================================================
def svd_eigenvalues(matrix, full_decomposition):
    """
    Computes the singular values of a matrix using Singular Value Decomposition (SVD).

    Parameters:
        matrix (ndarray): The input matrix to decompose.
        full_decomposition (bool): If True, returns (U, S, VT); otherwise, returns only S.

    Output:
        ndarray or tuple: Singular values if full_decomposition is False;
                          (U, S, VT) otherwise, where:
                           -  U = Unitary matrix with left singular vectors as columns.
                           -  S = 1-D array of singular values.
                           - VT = Unitary matrix with right singular vectors as rows.
    """
    U, S, VT = np.linalg.svd(matrix)
    return (U, S, VT) if full_decomposition else S

def cost_function_SM(X, Y):
    """
    Computes the similarity matching cost function: (1/T^2) * ||X^T X - Y^T Y||_F^2.

    Parameters:
        X (ndarray): Input data matrix of shape (n, T).
        Y (ndarray): Output data matrix of shape (m, T).

    Output:
        float: The computed cost value.
    """
    T = X.shape[1]
    frobenius_norm = np.linalg.norm(X.T @ X - Y.T @ Y, 'fro')
    return (frobenius_norm**2) / T**2

def compute_Y_opt(X, m):
    """
    Computes the optimal Y^star from [Liu et al., 2015].

    Parameters:
        X (ndarray): Input data matrix of shape (n, T).
        m (int): Dimensionality of the output representation (m <= n).

    Output:
        ndarray: Optimal output data matrix of shape (m, T).
    """
    eigenvalues, eigenvectors = np.linalg.eigh(X.T @ X)
    # Sort eigenvalues and corresponding eigenvectors in descending order
    idx = np.argsort(eigenvalues)[::-1]
    top_eigenvectors = eigenvectors[:, idx[:m]]
    top_eigenvalues = eigenvalues[idx[:m]]
    L_m = np.diag(top_eigenvalues)
    # Picking V = np.eye(m) as arbitrary orthogonal mxm matrix
    return np.sqrt(L_m) @ top_eigenvectors.T

def simulate_dynamics(W_0, M_0, Y_0, X, eps1, eps2, T, t_span, dt, noise_scale):
    """
    Simulates the dynamics with added noise in Y and M.

    Parameters:
        W_0 (ndarray): Initial condition for W.
        M_0 (ndarray): Initial condition for M.
        Y_0 (ndarray): Initial condition for Y.
        X (ndarray): Input data matrix of shape (n, T).
        eps1 (float): Small parameter for fastest time scale.
        eps2 (float): Small parameter for intermediate time scale.
        T (int): Number of data points (scaling).
        t_span (tuple): Time range for simulation (start, end).
        dt (float): Time step size for simulation.
        noise_scale (float): Scale of Gaussian noise added to dynamics.

    Outputs:
        tuple: (t, Y, M, W) where:
            t (ndarray): Time points;
            Y (ndarray): Solution array for Y;
            M (ndarray): Solution array for M;
            W (ndarray): Solution array for W.
    """
    n, T = X.shape
    m = W_0.shape[0]

    def system(t, z):
        W = z[:m * n].reshape(m, n)
        M = z[m * n:m * n + m * m].reshape(m, m)
        Y = z[m * n + m * m:].reshape(m, T)

        # Dynamics
        dW_dt = -4 * W + (4 / T) * Y @ X.T
        dM_dt = (-2 / eps2) * M + (2 / (T * eps2)) * Y @ Y.T
        dY_dt = (-4 / (T * eps1 * eps2)) * (M @ Y - W @ X)

        # Add Gaussian noise
        dM_dt += noise_scale * np.random.normal(0, 1, size=M.shape)
        dY_dt += noise_scale * np.random.normal(0, 1, size=Y.shape)

        return np.concatenate([dW_dt.ravel(), dM_dt.ravel(), dY_dt.ravel()])

    # Initial conditions
    z0 = np.concatenate([W_0.ravel(), M_0.ravel(), Y_0.ravel()])
    t_eval = np.arange(t_span[0], t_span[1], dt)

    # Solve the system
    sol = solve_ivp(system, t_span, z0, t_eval=t_eval, method='RK45')

    # Extract results
    t = sol.t
    W = sol.y[:m * n].reshape(m, n, -1)
    M = sol.y[m * n:m * n + m * m].reshape(m, m, -1)
    Y = sol.y[m * n + m * m:].reshape(m, T, -1)
    
    return t, Y, M, W
# ============================================================================
#                               Simulation
# ============================================================================
T = True
F = False
run_params = F
run_liu = F
run = F
#########################
simulation_params_path = 'simulation_parameters.npz'
if run_params:
    # Parameters
    n = 10                   # Dimensionality of the dataset
    m = 3                    # Reduced dimensionality
    k = 2000                 # Number of data points
    # Generate the data matrix X from its SVD -- Similar to 2017 Pehlevan, C., Sengupta, A. M., and Chklovskii, D. B.
    left_singular_vectors = np.linalg.qr(np.random.randn(n, n))[0]
    right_singular_vectors = np.linalg.qr(np.random.randn(k, n))[0]
    top_singular_values = [np.sqrt(3 * k), np.sqrt(2 * k), np.sqrt(k)]
    additional_singular_values = np.random.uniform(0, 0.1 * np.sqrt(k), n - 3)
    all_singular_values = np.concatenate((top_singular_values, additional_singular_values))
    X = left_singular_vectors @ np.diag(all_singular_values) @ right_singular_vectors.T
    print("all_singular_values = ", all_singular_values)

    C_X = X @ X.T / k
    np.savez_compressed(simulation_params_path, n=n, m=m, k=k, X=X, C_X=C_X)
else:
    params = np.load(simulation_params_path)
    n, m, k, X, C_X = params['n'], params['m'], params['k'], params['X'], params['C_X']

#########################
simulation_opt_liu_path = 'simulation_opt_liu.npz'
if run_liu:
    Y_opt_liu = compute_Y_opt(X, m)
    result_opt_liu = cost_function_SM(X, Y_opt_liu)
    np.savez_compressed(simulation_opt_liu_path, Y_opt_liu=Y_opt_liu, result_opt_liu=result_opt_liu)
else:
    opt_liu = np.load(simulation_opt_liu_path)
    Y_opt_liu, result_opt_liu = opt_liu['Y_opt_liu'], opt_liu['result_opt_liu']

########################
number_of_steps = 10
simulation_same_ic_path = 'simulation_noise.npz'
t_fin_multiplier = 400
dt = 0.01
eps1, eps2 = 0.01, 0.2
t_fin = 10 * eps2 * t_fin_multiplier
t_span = (0, t_fin)
noise = 1

result_dyn = []
eigenvalues_Y_dyn_list = []
eigenvalues_W_dyn_list = []

if run:
    for step in range(number_of_steps):
        print(f"Step = {step + 1}/{number_of_steps}")
        Y_0 = np.random.randn(m, k)
        W_0 = np.random.randn(m, n)
        M_0 = np.diag(np.abs(np.random.randn(m)))
        # Simulate dynamics
        t_dyn, Y_dyn, M_dyn, W_dyn = simulate_dynamics(W_0, M_0, Y_0, X, eps1, eps2, k, t_span, dt, noise)
        result_dyn.append(cost_function_SM(X, Y_dyn[:, :, -1]))
        eigenvalues_Y_dyn_list.append(svd_eigenvalues(Y_dyn[:, :, -1], False))
        eigenvalues_W_dyn_list.append(svd_eigenvalues(W_dyn[:, :, -1], False))

    np.savez_compressed(simulation_same_ic_path,
                        eigenvalues_Y_dyn_list=eigenvalues_Y_dyn_list,
                        eigenvalues_W_dyn_list=eigenvalues_W_dyn_list,
                        result_dyn=result_dyn)
else:
    load_both = np.load(simulation_same_ic_path)
    eigenvalues_Y_dyn_list = load_both['eigenvalues_Y_dyn_list']
    eigenvalues_W_dyn_list = load_both['eigenvalues_W_dyn_list']
    result_dyn = load_both['result_dyn']

# ============================================================================
#                               PLOTS
# ============================================================================
if run:
    eigenvalues_Y_dyn_list = np.array(eigenvalues_Y_dyn_list)
    eigenvalues_W_dyn_list = np.array(eigenvalues_W_dyn_list)    
save_fig = T
#### First Plot: Cost Difference Comparison
number_of_steps_dyn = len(result_dyn)
result_diff_dyn = np.array(result_dyn) - np.array(result_opt_liu)

plt.figure(figsize=(12, 4))#(14, 4)
plt.plot(range(1, number_of_steps_dyn + 1), result_diff_dyn, label=r'$SM(Y_{dyn}) - SM(Y^{\star})$', color='royalblue', linewidth=2)
plt.xlim([1, number_of_steps])
plt.legend(fontsize=18)
plt.grid(True, linestyle='--', alpha=0.7)
plt.tick_params(axis='both', labelsize=16)
plt.xlabel('Simulation', fontsize=20)
plt.ylabel('Cost Difference', fontsize=20)
plt.tight_layout()
if save_fig:
    #plt.savefig(f'cost_diff_noise.eps', bbox_inches='tight')
    plt.savefig(f'cost_diff_noise_NC.eps', bbox_inches='tight')
plt.show()

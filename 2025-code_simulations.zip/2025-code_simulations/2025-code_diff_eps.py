# Code to run the simulation in Section 6, paragraph "Different time-scale parameters"

import numpy as np
import random
import matplotlib.pyplot as plt
from matplotlib import rc
import seaborn as sns
from scipy.integrate import solve_ivp
from scipy.optimize import minimize, least_squares

# PLOT SETTINGS
sns.set(style="whitegrid")
font = {'size': 16}
plt.rc('font', **font)
rc('text', usetex=True)
rc('font', family='serif')

# ============================================================================
#                           Functions
# ============================================================================
def svd_eigenvalues(matrix, full_decomposition):
    """
    Computes the singular values of a matrix using Singular Value Decomposition (SVD).

    Parameters:
        matrix (ndarray): The input matrix to decompose.
        full_decomposition (bool): If True, returns (U, S, VT); otherwise, returns only S.

    Output:
        ndarray or tuple: Singular values if full_decomposition is False;
                          (U, S, VT) otherwise, where:
                           -  U = Unitary matrix with left singular vectors as columns.
                           -  S = 1-D array of singular values.
                           - VT = Unitary matrix with right singular vectors as rows.
    """
    U, S, VT = np.linalg.svd(matrix)
    return (U, S, VT) if full_decomposition else S

def cost_function_SM(X, Y):
    """
    Computes the similarity matching cost function: (1/T^2) * ||X^T X - Y^T Y||_F^2.

    Parameters:
        X (ndarray): Input data matrix of shape (n, T).
        Y (ndarray): Output data matrix of shape (m, T).

    Output:
        float: The computed cost value.
    """
    T = X.shape[1]
    frobenius_norm = np.linalg.norm(X.T @ X - Y.T @ Y, 'fro')
    return (frobenius_norm**2) / T**2

def compute_Y_opt(X, m):
    """
    Computes the optimal Y^star from [Liu et al., 2015].

    Parameters:
        X (ndarray): Input data matrix of shape (n, T).
        m (int): Dimensionality of the output representation (m <= n).

    Output:
        ndarray: Optimal output data matrix of shape (m, T).
    """
    eigenvalues, eigenvectors = np.linalg.eigh(X.T @ X)
    # Sort eigenvalues and corresponding eigenvectors in descending order
    idx = np.argsort(eigenvalues)[::-1]
    top_eigenvectors = eigenvectors[:, idx[:m]]
    top_eigenvalues = eigenvalues[idx[:m]]
    L_m = np.diag(top_eigenvalues)
    # Picking V = np.eye(m) as arbitrary orthogonal mxm matrix
    return np.sqrt(L_m) @ top_eigenvectors.T

def simulate_dynamics(W_0, M_0, Y_0, X, eps1, eps2, T, t_span, dt, noise_scale=0.0):
    """
    Simulates the dynamics with added noise in Y and M.

    Parameters:
        W_0 (ndarray): Initial condition for W.
        M_0 (ndarray): Initial condition for M.
        Y_0 (ndarray): Initial condition for Y.
        X (ndarray): Input data matrix of shape (n, T).
        eps1 (float): Small parameter for fastest time scale.
        eps2 (float): Small parameter for intermediate time scale.
        T (int): Number of data points (scaling).
        t_span (tuple): Time range for simulation (start, end).
        dt (float): Time step size for simulation.
        noise_scale (float): Scale of Gaussian noise added to dynamics (default 0.0).

    Outputs:
        tuple: (t, Y, M, W) where:
            t (ndarray): Time points;
            Y (ndarray): Solution array for Y;
            M (ndarray): Solution array for M;
            W (ndarray): Solution array for W.
    """
    n, T = X.shape
    m = W_0.shape[0]

    def system(t, z):
        W = z[:m * n].reshape(m, n)
        M = z[m * n:m * n + m * m].reshape(m, m)
        Y = z[m * n + m * m:].reshape(m, T)

        # Dynamics
        dW_dt = -4 * W + (4 / T) * Y @ X.T
        dM_dt = (-2 / eps2) * M + (2 / (T * eps2)) * Y @ Y.T
        dY_dt = (-4 / (T * eps1 * eps2)) * (M @ Y - W @ X)

        # Add Gaussian noise
        dM_dt += noise_scale * np.random.normal(0, 1, size=M.shape)
        dY_dt += noise_scale * np.random.normal(0, 1, size=Y.shape)

        return np.concatenate([dW_dt.ravel(), dM_dt.ravel(), dY_dt.ravel()])

    # Initial conditions
    z0 = np.concatenate([W_0.ravel(), M_0.ravel(), Y_0.ravel()])
    t_eval = np.arange(t_span[0], t_span[1], dt)

    # Solve the system
    sol = solve_ivp(system, t_span, z0, t_eval=t_eval, method='RK45')

    # Extract results
    t = sol.t
    W = sol.y[:m * n].reshape(m, n, -1)
    M = sol.y[m * n:m * n + m * m].reshape(m, m, -1)
    Y = sol.y[m * n + m * m:].reshape(m, T, -1)
    
    return t, Y, M, W

# ============================================================================
#                               Simulation
# ============================================================================
T = True
F = False
run_params = F
run_liu = F
run = F
#########################
simulation_params_path = 'simulation_parameters.npz'
if run_params:
    # Parameters
    n = 10                   # Dimensionality of the dataset
    m = 3                    # Reduced dimensionality
    k = 2000                 # Number of data points

    left_singular_vectors = np.linalg.qr(np.random.randn(n, n))[0]  # Ensure orthonormality
    right_singular_vectors = np.linalg.qr(np.random.randn(k, n))[0]  # Ensure orthonormality
    top_singular_values = [np.sqrt(3 * k), np.sqrt(2 * k), np.sqrt(k)]
    additional_singular_values = np.random.uniform(0, 0.1 * np.sqrt(k), n - 3)
    all_singular_values = np.concatenate((top_singular_values, additional_singular_values))
    X = left_singular_vectors @ np.diag(all_singular_values) @ right_singular_vectors.T
    C_X = X @ X.T / k
    np.savez_compressed(simulation_params_path, n=n, m=m, k=k, X=X, C_X=C_X)
else:
    params = np.load(simulation_params_path)
    n, m, k, X, C_X = params['n'], params['m'], params['k'], params['X'], params['C_X']

#########################
simulation_opt_liu_path = 'simulation_opt_liu.npz'
if run_liu:
    Y_opt_liu = compute_Y_opt(X, m)
    result_opt_liu = cost_function_SM(X, Y_opt_liu)
    np.savez_compressed(simulation_opt_liu_path, Y_opt_liu=Y_opt_liu, result_opt_liu=result_opt_liu)
else:
    opt_liu = np.load(simulation_opt_liu_path)
    Y_opt_liu, result_opt_liu = opt_liu['Y_opt_liu'], opt_liu['result_opt_liu']

########################
number_of_steps = 100
simulation_same_ic_path = 'simulation_diff_eps.npz'
t_fin_multiplier = 200
dt = 0.01

eps_pairs = [(0.001, 0.05), (0.005, 0.1), (0.01, 0.1), (0.02, 0.15), (0.02, 0.2),
             (0.03, 0.25), (0.03, 0.3), (0.05, 0.4), (0.05, 0.5), (0.2, 0.5)]

all_results_dyn = []
all_eigenvalues_Y_dyn = []
all_eigenvalues_W_dyn = []

if run:
    for idx, (eps1, eps2) in enumerate(eps_pairs):
        print(f"Running simulation {idx + 1}/{len(eps_pairs)} with eps1={eps1}, eps2={eps2}")
        t_fin = 10 * eps2 * t_fin_multiplier
        t_span = (0, t_fin)
        
        result_dyn = []
        eigenvalues_Y_dyn_list = []
        eigenvalues_W_dyn_list = []
        
        for step in range(number_of_steps):
            print(f"Step = {step + 1}/{number_of_steps}")
            Y_0 = np.random.randn(m, k)
            W_0 = np.random.randn(m, n)
            M_0 = np.diag(np.abs(np.random.randn(m)))
            # Simulate dynamics
            t_dyn, Y_dyn, M_dyn, W_dyn = simulate_dynamics(W_0, M_0, Y_0, X, eps1, eps2, k, t_span, dt)
            result_dyn.append(cost_function_SM(X, Y_dyn[:, :, -1]))
            eigenvalues_Y_dyn_list.append(svd_eigenvalues(Y_dyn[:, :, -1], False))
            eigenvalues_W_dyn_list.append(svd_eigenvalues(W_dyn[:, :, -1], False))
        
        # Store results for this (eps1, eps2) pair
        all_results_dyn.append(result_dyn)
        all_eigenvalues_Y_dyn.append(np.array(eigenvalues_Y_dyn_list))
        all_eigenvalues_W_dyn.append(np.array(eigenvalues_W_dyn_list))

    np.savez_compressed(simulation_same_ic_path,
                        all_results_dyn=all_results_dyn,
                        all_eigenvalues_Y_dyn=all_eigenvalues_Y_dyn,
                        all_eigenvalues_W_dyn=all_eigenvalues_W_dyn)
else:
    load_data = np.load(simulation_same_ic_path)
    all_results_dyn = load_data['all_results_dyn']
    all_eigenvalues_Y_dyn = load_data['all_eigenvalues_Y_dyn']
    all_eigenvalues_W_dyn = load_data['all_eigenvalues_W_dyn']
# ============================================================================
#                               PLOTS
# ============================================================================
save_fig = T

selected_indices = [2, 3, 4, 5, 8, 9]
selected_eps_pairs = [eps_pairs[i] for i in selected_indices]
n_rows = 3
n_cols = 2
#fig, axes = plt.subplots(n_rows, n_cols, figsize=(11, 7), sharex=True)
fig, axes = plt.subplots(n_rows, n_cols, figsize=(10.5, 8), sharex=True)
axes = axes.flatten()
for idx, (eps1, eps2) in enumerate(selected_eps_pairs):
    x_range = range(1, number_of_steps + 1)
    result_diff_dyn = np.array(all_results_dyn[selected_indices[idx]]) - np.array(result_opt_liu)
    ax = axes[idx]
    ax.plot(x_range, result_diff_dyn, label=f"$\\varepsilon_1$={eps1:.2f}, $\\varepsilon_2$={eps2:.2f}", color=f"C{idx}")
    ax.set_xlim([1, number_of_steps])
    ax.grid(True, linestyle='--', alpha=0.7)
    ax.legend(fontsize=15)
    ax.set_xticks([1, 20, 40, 60, 80, 100])
    ax.tick_params(axis='both', labelsize=16)
#fig.text(0.53, 0.04, 'Simulation', ha='center', fontsize=17)
#fig.text(0.04, 0.5, r'Cost Difference', va='center', rotation='vertical', fontsize=17)
fig.text(0.53, 0.04, 'Simulation', ha='center', fontsize=19)
fig.text(0.04, 0.5, r'Cost Difference', va='center', rotation='vertical', fontsize=19)
plt.tight_layout(rect=[0.05, 0.05, 1, 0.95])
if save_fig:
    #plt.savefig('cost_diff_eps.eps', bbox_inches='tight')
    plt.savefig('cost_diff_eps_NC.eps', bbox_inches='tight')
plt.show()
